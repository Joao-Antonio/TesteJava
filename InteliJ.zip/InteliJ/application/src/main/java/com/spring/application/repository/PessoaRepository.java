package com.spring.application.repository;

import com.spring.application.domain.Pessoa;
import org.springframework.data.repository.CrudRepository;

public interface PessoaRepository extends CrudRepository <Pessoa, Integer> {
}
