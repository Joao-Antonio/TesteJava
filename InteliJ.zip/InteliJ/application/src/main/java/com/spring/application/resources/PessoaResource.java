package com.spring.application.resources;


import com.spring.application.domain.Pessoa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.spring.application.repository.PessoaRepository;

@RestController
@RequestMapping("/api")
public class PessoaResource {

    @Autowired
    private PessoaRepository pessoaRepository;

    @GetMapping(path = "/pessoa")
    public String listaPessoas(){

        return "Online";
    }


//
//    @GetMapping(path = "/api/pessoa/{codigo}")
//    public ResponseEntity consultar(@PathVariable("codigo") Integer codigo){
//        return repository.findById(codigo)
//                .map(record -> ResponseEntity.ok().body(record))
//                .orElse(ResponseEntity.notFound().build());
//    }
//
//    @PostMapping(path = "/api/pessoa/salvar")
//    public Pessoa salvar(@RequestBody Pessoa pessoa){
//        return repository.save(pessoa);
//    }
}
